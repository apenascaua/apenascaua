public class Bolo{
  private String recheio;
  private String massa;
  private String cobertura;
  private boolean decoracao;

public Bolo(String recheio, String massa, String cobertura, boolean decoracao){

  this.recheio = recheio;
  this.massa = massa;
  this.cobertura = cobertura;
  this.decoracao = decoracao;
    
  }
}