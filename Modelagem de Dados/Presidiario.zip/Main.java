class Main {
  public static void main(String[] args) {
    Bolo bolinho = new Bolo("morango", "chocolate", "limão", true);
    //String recheio, String massa, String cobertura, boolean decoracao
    Confeitaria c = new Confeitaria("vanderlei", "show", bolinho);
    //String confeiteiro, String clientela, Bolo bolo
    System.out.println("deu certo :D");
  }
}