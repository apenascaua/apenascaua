public class AgentePenal{

public Funcionario(String nome, String cpf, String dataNascimento, String contato, String genero, String endereco, String cargo, int cargaHoraria, boolean bateuPonto, String pis, float salario, float valeTransporte, float valeAlimentacao){

  super(nome, cpf, dataNascimento, contato, genero, endereco, cargo, cargaHoraria, bateuPonto, pis, salario, valeTransporte, valeAlimentacao)}

  public boolean vigiar(Pavilhao){
     return true;
    }
    
  public boolean acompanharPresidiario(Presidio){
     return true;
}
 
  public boolean transferirPresidiario(Presidio){
     return true;
    }
  
  public void advertir(Presidiario, String){
     return true;
    }
  
  public void advertir(Visitante, String){
     return true;
    }
  
  public void advertir(Presidiario, Visitante, String){
     return true;
    }
  
  public boolean conferir(Pavilhao){
     return true;
    }
  
  public boolean conferir(Presidiario){
     return true;
    }
  
  public boolean revistar(Presidio){
     return true;
    }
  
  public boolean revistar(Visitante){
     return true;
    }