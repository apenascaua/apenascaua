
import java.util.ArrayList;

public class Presidio{
private String nome;
private String local;
private String contato;
private float despesa;
private float orcamento;
private int lotacao;
private ArrayList<String> estoque;
private ArrayList<String> sistemaSeguranca;
private ArrayList<String> transporte;
private ArrayList<Pessoa> pessoa;
private ArrayList<Pavilhao> pavilhao;
}

public Presidio (String nome, String local, String contato, float despesa, float orcamento, int lotacao) {
  this.nome = nome;
  this.local = local;
  this.contato = contato;
  this.despesa = despesa;
  this.orcamento = orcamento;
  this.lotacao = lotacao;
}



