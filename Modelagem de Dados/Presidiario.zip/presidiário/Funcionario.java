public class Funcionario{
  private String cargo;
  private int cargaHoraria;
  private boolean bateuPonto;
  private String pis;
  private float salario;
  private float valeTransporte;
  private float valeAlimentacao;

public Funcionario(String nome, String cpf, String dataNascimento, String contato, String genero, String endereco, String cargo, int cargaHoraria, boolean bateuPonto, String pis, float salario, float valeTransporte, float valeAlimentacao){

  super(nome, cpf, dataNascimento, contato, genero, endereco)
  this.cargo = cargo;
  this.cargaHoraria = cargaHoraria;
  this.bateuPonto = bateuPonto;
  this.pis = pis;
  this.salario = salario;
  this.valeTransporte = valeTransporte;
  this.valeAlimentacao = valeAlimentacao;
    
  }

  public boolean baterPonto(){
     return true;
     
   }

  public boolean aumentarSalario(float, String, int){
      return true;
      
    }

  public boolean aumentarSalario(float, String){
     return true;
     
   }

  public boolean receberSalario(){
     return true;
     
   }

  public boolean receberVale(String){
     return true;
     
   }

  public boolean tirarFerias(String){
     return true;
     
   }

  public void trabalhar(){
     return true;
     
   }

  public int fazerHoraExtra(){
     return true;
     
   }

  public boolean serTransferido(Pavilhao){
     return true;
     
   }

  public void serDemitido(String, String){
     return true;
     
   }

  public void pedirDemissao(String, String, String){
     return true;
     
   }
  
}