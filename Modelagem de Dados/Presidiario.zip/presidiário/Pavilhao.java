import java.util.ArrayList;

public class Pavilhao{
  private int cela;
  private int refeitorio;
  private int banheiro; 
  private int solitaria;
  private ArrayList<Presidiario> presidiario;
  private ArrayList<Funcionario> funcionario;
  private int id;
  private String tipo;
  private int patio;
  private int biblioteca;
  private int lavanderia;
  private int salaDeAula;
  private ArrayList<String> salasTecnico;
  private int capela;
  private Arraylist<String> SalaDeVisita;
  private boolean lojaConveniencia;
    }

public Pavilhao(int cela, int refeitorio, int banheiro, int solitaria, int id, String tipo, int patio, int biblioteca, int lavanderia, int salaDeAula, int capela, boolean lojaConveniencia){
  
  this.cela = cela;
  this.refeitorio = refeitorio;
  this.banheiro = banheiro;
  this.solitaria = solitaria;
  this.id = id;
  this.tipo = tipo;
  this.patio = patio;
  this.biblioteca = biblioteca;
  this.lavanderia = lavanderia;
  this.salaDeAula = salaDeAula;
  this.capela = capela;
  this.lojaConveniencia = lojaConveniencia;
  }