public class Pessoa{
  private String nome;
  private String cpf;
  private String dataNascimento;
  private String dataNascimento;
  private String genero;
  private String endereco;

public Pessoa(String nome, String cpf, String dataNascimento, String contato, String genero, String endereco){

  this.nome = nome;
  this.cpf = cpf;
  this.dataNascimento = dataNascimento;
  this.contato = contato;
  this.genero = genero;
  this.endereco = endereco;
  this.funcionario = funcionario;
    
  }

  public void registrar(String, String, String, String, String){
     return true;
     
   }

  public boolean verificaPresenca(String, String){
      return true;
      
    }
  
}