public class{
  private int codigo;
  private String crime;
  private int numCela;
  private String advogado;
  private int tempoSentencaMeses;
  private boolean julgamento;
  private boolean fianca;
  private String atividade;
}
public Presidiario(String nome, String cpf, String dataNascimento, String contato, String genero, String endereco, int codigo, String crime, int numCela, String advogado){

  super(nome, cpf, dataNascimento, contato, genero, endereco)
  this.codigo = codigo;
  this.crime = crime;
  this.numCela = numCela;
  this.advogado = advogado;
}
public void tatuar(String){
  return true;
}

public boolean receberVisita(String, String, String){
  return true;
}

public booelan receberLigacao(String, String, String, String)


public boolean fazerLigacao(String, int, String, String){
      return true;
      
    }

public void serLiberado(String, String){
      return true;
      
    }

public  boolean serTransferido(int, pavilhao, Funcionario){
  return true;
}


public void sair(String, String, String){
      return true;
      
    }  

public void comparecerJulgamento(String, String, String, Funcionario){
      return true;
      
    }

public boolean banhoDeSol(){
      return true;
      
    }

public boolean irParaSolitaria(String, String, int){
      return true;
      
    }

public boolean serRecolhido(int){
  return true;
}

                            