import java.util.ArrayList;

public class Visitante{
  private String dataVisita;
  private String tipoVisita;
  private String relacao;
  private int horaVisita;
  private int minVisita;
  private int horaSaida;
  private int minSaida;
  private ArrayList<String> pertences;
  private ArrayList<String> presente;
}

public Visitante(String dataVisita, String tipoVisita, String relacao, int horaVisita, int minVisita, int horaSaida, int minSaida, String nome, String cpf, String dataNascimento, String contato, String genero, String endereco){
  
super(nome, cpf, dataNascimento, contato, genero, endereco);
 this.dataSaida = dataSaida; 
 this.tipoVisita = tipoVisita;
 this.relacao = relacao;
 this.horaVisita = horaVisita;
 this.minVisita = minVisita;
 this.horaSaida = horaSaida;
 this.minSaida = minSaida;
}

public String revistar(String, String){
      return "Não tinha nada";
  }

public boolean agendarVisita(String, String, String, String, int,  int, String, String){
      return true;
  }

public boolean presentear(String){
  return true;
}