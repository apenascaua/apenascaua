public class Cartao{
  private int id;
  private String nomeUsuario;
  private boolean serAluno;
  private boolean serIdoso;
  private boolean serCidadão;
  private boolean turista;
  private boolean especiais;
  private boolean valeTransporte
  private int validade;
  private ArrayList<Linhas> linhas;
}
  
public Cartao( int id, String nomeUsuario, boolean serAluno, boolean serIdoso, boolean serCidadão, boolean turista, boolean especiais, boolean valeTransporte, int validade ){

  this.id = id;
  this.nomeUsuario = nomeUsuario;
  this.serAluno = serAluno;
  this.serIdoso = serIdoso;
  this.serCidadao = serCidadao;
  this.turista = turista;
  this.especiais = especiais;
  this.valeTransporte = valeTransporte;
  this.validade = validade;
    
  }

  public boolean recarregarCartao(){
     return true;
     
   }

  public boolean renovarCartao(){
      return true;
    }

  public void perderCartao(){
     return true;
     
   }

  public void roubarCartao(){
     return true;
     
   }

  public void quebrarCartao(){
     return true;
     
   }
  
}