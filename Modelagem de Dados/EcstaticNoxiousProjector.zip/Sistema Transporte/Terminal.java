public class Terminal{
  private String nome;
  private String local;
  private int tamanho; 
  private int vendinhas;
  private int quantidadePontos;
  private int armazenamentoOnibus;
  private boolean centralAtendimento;
    }

public Terminal(String nome, String local, int tamanho, int vendinhas, int quantidadePontos, int armazenamentoOnibus, boolean centralAtendiamento){
  
  this.nome = nome;
  this.local = local;
  this.tamanho = tamanho;
  this.vendinhas = vendinhas;
  this.quantidadePontos = quantidadePontos;
  this.armazenamentoOnibus = armazenamentoOnibus;
  }