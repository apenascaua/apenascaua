public class Passageiro{
  private ArrayList <Linhas> horarioLinhas
  private String pontoPartida;
  private String pontoSaida;
  private boolean pagar;
  private float salario;
  private float valeTransporte;
  private boolean cartao;
  private ArrayList <Cartao> tipocartao;
}
  
public Passageiro(String pontoPartida, String pontoSaida, boolean pagar, float salario, float valeTransporte, boolean cartao){

  super(nome, cpf, dataNascimento, contato, genero, endereco, linhas, cartao)
  this.pontoPartida = pontoPartida;
  this.pontoSaida = pontoSaida;
  this.pagar = pagar;
  this.salario = salario;
  this.valeTransporte = valeTransporte;
  this.cartao = cartao;
    
  }

  public boolean pagarMotorista{
     return true;
     
   }


  public boolean pagarMaquininha(){
     return true;
     
   }

  public boolean naoPagar(){
      return true;
      
    }

  public boolean terCartao(){
     return true;
     
   }

  public void passeLivre(){
     return true;
     
   }

  public boolean puxarCordinha(){
     return true;
     
   }

  public void perderPonto(){
     return true;
     
   }

  public boolean vandalismo(){
     return true;
     
   }
  
}