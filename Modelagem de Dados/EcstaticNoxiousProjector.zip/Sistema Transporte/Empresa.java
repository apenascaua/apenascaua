public class enmpresa{
  private String nome;
  private String local;
  private ArrayList <Pessoa> Pessoa;
  private ArrayList <String> estoque;
  private float despesa;
  private float orcamento 
  private ArrayList <String> transporte;
  private ArrayList <String> sistemaSeguranca;
  private int funcionarios;
  private ArrayList<Linhas> linhas;
}
  
public empresa( String nome, String local, float despesa, float orcamento, int funcionarios){
   
  super(Pessoa, linhas)
  this.nome = nome;
  this.local = local;
  this.despesa = despesa;
  this.orcamento = orcamento;
  this.funcionarios = funcioarios;
  
  }

  public boolean contratarPessoa(){
     return true;
     
   }

  public boolean demitirFuncionario(){
      return true;
    }

  public int Despesas(){
     return true;
     
   }

  public boolean desviarDinheiro(){
     return true;
     
   }

  public void quebrarCartao(){
     return true;
     
   }
  
}