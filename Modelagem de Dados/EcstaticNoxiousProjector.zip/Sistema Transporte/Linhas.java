public class Linhas{
  private String motorista;
  private String pontoInicial;
  private String pontoFinal; 
  private String rota;
  private int horarioPartida;
  private int horarioFinal;
  private ArrayList <Empresa> empresa;
    }

public Linhas(String motorista, String pontoInicial, String pontoFinal, String rotas, int horarioPartida, int horarioFinal){
  
  super(Empresa)
  this.motorista = motorista;
  this.pontoInical = pontoInical;
  this.pontoFinal = pontoFinal;
  this.rota = rota;
  this.horarioPartida = horarioPartida;
  this.horarioFinal = horarioFinal;
  }