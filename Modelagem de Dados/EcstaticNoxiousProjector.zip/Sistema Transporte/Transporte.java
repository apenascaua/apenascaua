public class Transporte{
  private String cor;
  private String chassi;
  private int placa;
  private int ipva
  private ArrayList <Empresa> empresa;
  private ArrayList <Linhas> rotas;
}
  
public Transporte( String cor, String chassi, int placa, int ipva){
   
  super(Empresa, linhas)
  this.cor = cor;
  this.chassi = chassi;
  this.placa = placa;
  this.ipva = ipva;
  
  }

  public boolean reparar(){
     return true;
     
   }

  public boolean sofrerVandalismo(){
      return true;
    }

  public void atrasar(){
     return true;
     
   }

  public void chegarAdiantado(){
     return true;
     
   }
  
}