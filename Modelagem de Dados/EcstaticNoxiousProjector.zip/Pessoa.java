public class Pessoa{
  private String nome;
  private int idade;
  private Roupa roupa;

 public Pessoa(String nome, int idade){
   this.nome = nome;
   this.idade = idade;
   }

    public void and (int idade){

    }

    public String get_nome(){
      return nome;
      
    }
}