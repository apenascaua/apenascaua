public class Livro{
  private String autor;
  private String genero;
  private String editora;
  private boolean capa_dura;


  public Livro(String a, String g, String e, boolean c){
    autor = a;
    genero = g;
    editora = e;
    capa_dura = c;
    }

    public boolean alugar (String a){
      return true;

    }
  
    public boolean ler (String a){
      return true;

    }

} 