 npublic class Computador{
  private String resolucao;
  private String modelo;
  private String marca;
  private String potencia;
  private String tensao;


  public Computador(String r, String mo, String ma, String p, String t){
    resolucao = r;
    modelo = mo;
    marca = ma;
    potencia = p;
    tensao = t;
    }

    public boolean ligar (String t){
      return true;

    }
  
  public boolean desligar (String t){
      return true;

    }

    public void configurar (){
      
    }
}