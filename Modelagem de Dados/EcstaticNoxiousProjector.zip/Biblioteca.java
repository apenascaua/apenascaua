public class Biblioteca{
  private String bibliotecario;
  private ArrayList<String> cadastro_livros;
  private ArrayList<String> cadastro_clientes;
  private Computador computador;
  private Livros livros;
  
 public Biblioteca(String bibliotecario, String cadastro_livros, String cadastro_clientes, Computador computador, Livros livros){
   
   this.bibliotecario = bibliotecario;
   this.cadastro_livros = cadastro_livros;
   this.cadastro_clientes = cadastro_clientes;
   this.computador = computador;
   this.livros = livros;
   }

    public void and (String cadastro_livros){

    }

    public String get_livro(){
      return cadastro_livro;
      
    }
  
  public String get_clientes(){
      return cadastro_clientes;
      
    
    }

  public String get_bibliotecario(){
      return cadastro_bibliotecario;
      
    }
}