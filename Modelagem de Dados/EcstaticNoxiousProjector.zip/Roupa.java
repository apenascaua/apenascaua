public class Roupa{
  private String tamanho;
  private String cor;
  private String material;


  public Roupa(String t, String c, String m){
    tamanho = t;
    cor = c;
    material = m;
    }

    public boolean ajustar (String t){
      return true;

    }

    public void vestir (){
      
    }
}