package com.example.carlos;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    EditText campo, senha;
    TextView exibe;
    ArrayList<user> usu = new ArrayList<>();
    user encontrado;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        campo = findViewById(R.id.insano);
        exibe = findViewById(R.id.t);
        senha = findViewById(R.id.senha);
        user u = new user("carlos", "321", 1 );
        user u2 = new user("eren", "123", 2);
        usu.add(u);
        usu.add(u2);
    }

    public void clica(View c) {
        if (verificauser(campo.getText().toString(), senha.getText().toString())) {
            String texto = campo.getText().toString();
            Toast.makeText(this, "TATAKAE :D " + texto, Toast.LENGTH_LONG).show();
            exibe.setText(texto);
            campo.setText(null);
            if (encontrado.perfil == 1) {
                mudaTela();


            } else if (encontrado.perfil == 2) {
                Tela_Admin.list = usu;
                mudaTeladmin();


            }
        } else {
            Toast.makeText(this, "ai calica usuario invalido :(", Toast.LENGTH_LONG).show();
        }

    }


    public void mudaTela(){

        Intent i = new Intent(this, Tela2.class);
        startActivity(i);
    }
    public void mudaTeladmin() {

        Intent g = new Intent(this, Tela_Admin.class);
        startActivity(g);
    }
    public boolean verificauser(String insano, String senha){
        for (user pessoa:usu){
            if(insano.equals(pessoa.login) && senha.equals(pessoa.senha)){
                encontrado = pessoa;
                return true;

            }
        }
        return false;

    }
}