package com.example.carlos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class Tela_Admin extends AppCompatActivity {
    EditText login, senha;
            CheckBox adm;
            static ArrayList<user> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        getSupportActionBar().hide();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_admin);
        login = findViewById(R.id.loginadm);
        senha = findViewById(R.id.senhaadm);
        adm = findViewById(R.id.checkadm);


    }

    public void cadastro(View c ) {
        String l = login.getText().toString();
        String s = senha.getText().toString();
        if (adm.isChecked()){
            user u = new user(l,s,2);
            list.add(u);


        }
        else{
            user u = new user(l,s,1);
        }
        Toast.makeText(this, "TATAKAE", Toast.LENGTH_LONG).show();

    }
}