package com.example.carlos;

public class user {
    String login, senha;
    int perfil;

    public user(String login, String senha) {
        this.login = login;
        this.senha = senha;
    }

    public user(String login, String senha, int perfil) {
        this.login = login;
        this.senha = senha;
        this.perfil = perfil;
    }
}
