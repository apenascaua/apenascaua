package com.example.geometriaespacial20;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    RadioButton at, aba, abv, n, f, v, h;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().hide();
        at = findViewById(R.id.at);
        aba = findViewById(R.id.aba);
        abv = findViewById(R.id.abv);
        n = findViewById(R.id.n);
        f = findViewById(R.id.f);
        v = findViewById(R.id.v);
        h = findViewById(R.id.h);
    }

    public void click(View vw) {
        Intent i = new Intent(this, calculo.class);
        if (at.isChecked()) {
            calculo.formula = 1;
            startActivity(i);

        } else if (aba.isChecked()) {
            calculo.formula = 2;
            startActivity(i);

        } else if (abv.isChecked()) {
            calculo.formula = 3;
            startActivity(i);

        } else if (n.isChecked()) {
            calculo.formula = 4;
            startActivity(i);

        } else if (f.isChecked()) {
            calculo.formula = 5;
            startActivity(i);

        } else if (v.isChecked()) {
            calculo.formula = 6;
            startActivity(i);

        } else if (h.isChecked()) {
            calculo.formula = 7;
            startActivity(i);

        } else {
            Toast.makeText(this, "escolha uma option", Toast.LENGTH_LONG).show();
        }
    }
}
